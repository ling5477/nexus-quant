import pathlib,json,subprocess,os,shutil,tempfile,fnmatch,hashlib,tarfile
root=pathlib.Path('/mnt/e/Project/nexus-quant-gateaudit'); out=root/'backend/nq-app/target/l6-chunk-safe-secret-scan'; binary=root/'backend/nq-app/target/l5-evidence-scan/gitleaks'; env=dict(os.environ,GIT_DIR='/mnt/e/Project/nexus-quant/.git/worktrees/nexus-quant-gateaudit',GIT_WORK_TREE=str(root))
lock=json.loads((root/'scripts/ci/delivery-supply-chain-lock.json').read_text()); identity=next(x for x in lock['tools'] if x['name']=='gitleaks'); arc=root/'artifacts/20260906-l4-canonical-reachability'/identity['artifact']; assert hashlib.sha256(arc.read_bytes()).hexdigest()==identity['sha256']
with tarfile.open(arc) as t: assert t.extractfile('gitleaks').read()==binary.read_bytes()
assert subprocess.check_output([str(binary),'version'],text=True).strip()=='8.18.4'
files=set(subprocess.check_output(['git','-C',str(root),'ls-files','-z'],env=env).decode().strip('\0').split('\0')); files.update(['scripts/ci/verify-reviewed-gitleaks-findings.py','scripts/ci/reviewed-gitleaks-findings.json','scripts/ci/tests/test_reviewed_gitleaks_findings.py'])
excluded=['.env','.env.*','*/.env','*/.env.*','secrets','secrets/*','*/secrets/*','credentials','credentials/*','*/credentials/*','*.pem','*.key','*.p12','*.jks','*.keystore','.git/*','*/target/*','*/node_modules/*','*/dist/*','*/build/*','*/coverage/*','*.log','logs/*','*/logs/*','log/*','*/log/*','*.dump','dumps/*','*/dumps/*','dump/*','*/dump/*','*.bak','*.backup','backups/*','*/backups/*','backup/*','*/backup/*']
files=sorted(p for p in files if not any(fnmatch.fnmatchcase(p,x) for x in excluded)); registry=json.loads((root/'scripts/ci/reviewed-gitleaks-findings.json').read_text()); results={}
def scan(source,name,redact=True):
 report=out/(name+'.json'); args=[str(binary),'detect','--source',str(source),'--no-git','--config',str(out/'gitleaks.toml'),'--report-format','json','--report-path',str(report),'--exit-code','2','--no-banner']; args+=['--redact'] if redact else []; p=subprocess.run(args,capture_output=True); return p.returncode,report,json.loads(report.read_text())
def verify(repo,source,report,real=False):
 p=subprocess.run(['python3',str(root/'scripts/ci/verify-reviewed-gitleaks-findings.py'),'--repository-root',str(repo),'--source-root',str(source),'--report',str(report),'--registry',str(root/'scripts/ci/reviewed-gitleaks-findings.json')],env=env if real else None,capture_output=True,text=True); return p
with tempfile.TemporaryDirectory(prefix='nq-chunk-proof-') as temp:
 temp=pathlib.Path(temp); source=temp/'safe'; source.mkdir()
 for path in files:
  target=source/path; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(root/path,target)
 rc,report,findings=scan(source,'real-candidate'); assert rc==2 and len(findings)==4,(rc,len(findings))
 gate=verify(root,source,report,True); (out/'real-verifier.log').write_text(gate.stdout+gate.stderr); assert gate.returncode==0,gate.stdout; results['candidate']={'safeFiles':len(files),'rawFindings':4,'reviewed':4,'unknown':0,'gate':'PASS'}
 repo=temp/'negative'; repo.mkdir(); subprocess.run(['git','init','-q',str(repo)],check=True)
 for path in sorted(set(x['path'] for x in registry['entries'])):
  dst=repo/path; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(root/path,dst)
 subprocess.run(['git','-C',str(repo),'add','--',*sorted(set(x['path'] for x in registry['entries']))],check=True)
 _,before,known=scan(repo,'isolated-known',False); assert verify(repo,repo,before).returncode==0
 entry=next(x for x in registry['entries'] if '/fa631' in x['path']); p=repo/entry['path']; raw=p.read_bytes(); line=raw.decode().splitlines()[entry['startLine']-1]; token=json.loads('{'+line.strip().rstrip(',')+'}')['sampleToken']; mutation=token[:-1]+'8'; assert token!=mutation and len(token)==len(mutation); p.write_bytes(raw.replace(token.encode(),mutation.encode()))
 rc,mutated,unknown=scan(repo,'isolated-prefix-mutated',False); assert rc==2 and len(unknown)==4; before_match=next(f for f in known if f['StartLine']==entry['startLine']); after_match=next(f for f in unknown if f['StartLine']==entry['startLine']); assert before_match['Secret']==after_match['Secret']
 gate=verify(repo,repo,mutated); (out/'mutated-verifier.log').write_text(gate.stdout+gate.stderr); assert gate.returncode!=0 and 'FILE_SHA_MISMATCH' in gate.stdout; results['prefixMutation']={'rawFindings':4,'sameTruncatedSecret':True,'verifier':'REJECT','reason':'FILE_SHA_MISMATCH'}
results['scannerIdentity']={'version':'8.18.4','archiveSha256':identity['sha256'],'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest()}; (out/'real-results.json').write_text(json.dumps(results,indent=2)); print(json.dumps(results))
