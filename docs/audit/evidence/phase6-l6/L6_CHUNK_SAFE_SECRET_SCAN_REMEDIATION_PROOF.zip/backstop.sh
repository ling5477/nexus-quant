set -euo pipefail

safe_list="${RUNNER_TEMP}/nq-secret-scan-safe-files.0"
patterns="${RUNNER_TEMP}/nq-secret-scan-patterns.txt"
violations="${RUNNER_TEMP}/nq-secret-scan-backstop-violations.txt"
: > "${violations}"

append_backstop_rule() {
  local rule="$1"
  shift
  printf '%s ' "${rule}" >> "${patterns}"
  printf '%s' "$@" >> "${patterns}"
  printf '\n' >> "${patterns}"
}

append_backstop_rule "anthropic_key" 'sk-ant-[A-Za-z0-9_-]{20,}'
append_backstop_rule "openai_proj_key" 'sk-proj-[A-Za-z0-9_-]{20,}'
append_backstop_rule "openai_key" 'sk-[A-Za-z0-9]{32,}'
append_backstop_rule "github_fine_pat" 'github_pat_[A-Za-z0-9_]{20,}'
append_backstop_rule "github_classic_pat" 'gh[pousr]_[A-Za-z0-9]{30,}'
append_backstop_rule "aws_akia" 'AKIA[0-9A-Z]{16}'
append_backstop_rule "aws_asia" 'ASIA[0-9A-Z]{16}'
append_backstop_rule "pem_private" "-----BEGIN (RSA |EC |OPENSSH |DSA |PGP )?" "PRIVATE" " " "KEY-----"
append_backstop_rule "slack_bot" 'xoxb-[A-Za-z0-9-]{10,}'
append_backstop_rule "slack_user" 'xoxp-[A-Za-z0-9-]{10,}'
append_backstop_rule "mnemonic_value" '(mnemonic|seed[_-]?phrase)["'\'']?[[:space:]]*[:=][[:space:]]*["'\'']([a-z]+[[:space:]]+){5,}[a-z]+'
append_backstop_rule "suspicious_assignment" "(api[_-]?key|api[_-]?secret|client[_-]?secret|pass" "phrase|private[_-]?key|access[_-]?token|auth[_-]?token|encrypted_payload|decrypted_payload)[\"']?[[:space:]]*[:=][[:space:]]*[\"'][A-Za-z0-9/+_=-]{20,}[\"']"

# Placeholder / non-real markers dropped from value-bearing patterns only.
placeholder='REPLACE_WITH_LOCAL|CHANGE_ME|DUMMY|dummy|FAKE|fake|test-only|example|EXAMPLE|placeholder|PLACEHOLDER|YOUR_|\$\{|getenv|process\.env|import\.meta\.env|Zm9v|<[A-Za-z]'

# Precise allowlist: PEM-material rule on the 4 known Binance fake-key / protocol-constant files.
allow_pem='(adapter/binance/service/BinanceRuntimeConfigTest\.java|adapter/binance/service/BinanceRequestSignerTest\.java|adapter/binance/service/BinanceHttpClientTest\.java|adapter/binance/service/BinanceEd25519RequestSigner\.java)$'

while IFS=' ' read -r name re; do
  [ -z "${name}" ] && continue
  files="$(xargs -0 grep -lE -e "${re}" < "${safe_list}" 2>/dev/null || true)"
  [ -z "${files}" ] && continue
  while IFS= read -r f; do
    [ -z "${f}" ] && continue
    if [ "${name}" = "suspicious_assignment" ] || [ "${name}" = "mnemonic_value" ]; then
      c="$(grep -InE -e "${re}" "${f}" 2>/dev/null | grep -ivE -e "${placeholder}" | wc -l)"
      [ "${c}" -eq 0 ] && continue
    fi
    if [ "${name}" = "pem_private" ] && printf '%s' "${f}" | grep -qE -e "${allow_pem}"; then
      continue
    fi
    # Report file + pattern name only. Never print source content.
    echo "${name} | ${f}" >> "${violations}"
  done <<< "${files}"
done < "${patterns}"

count="$(wc -l < "${violations}" | tr -d ' ')"
if [ "${count}" -gt 0 ]; then
  echo "Custom regex backstop found ${count} non-allowlisted match(es) (file + pattern only):" >&2
  cat "${violations}" >&2
  exit 1
fi
echo "Custom regex backstop: no non-allowlisted matches over tracked safe tree."
